import os
import math
import time
import rclpy
import signal
import threading
from rclpy.node import Node
from std_srvs.srv import Trigger
from nav_msgs.msg import Odometry
from std_msgs.msg import String,UInt32
from geometry_msgs.msg import Pose2D, Pose, Twist, PoseWithCovarianceStamped, TransformStamped


class MoveForward(Node):
    def __init__(self,name):
        super().__init__(name)
        self.pub_vel=self.create_publisher(Twist,"/controller/cmd_vel",1)#发布速度控制
        self.pub_flag=self.create_publisher(UInt32,"flag",1)#发布是否开始导航

        self.odom_sub = self.create_subscription(Odometry, 'odom_raw', self.odom_callback, 10)#接收odom数据
        #self.start_sub = self.create_subscription(String, 'detected_color', self.color_callback, 10)#接收到数据说明可以启动
        self.sub_flag=self.create_subscription(UInt32,"flag",self.flag_callback,10)

        #self.start_moving=False#是否启动
        self.start_moving=False
        self.task_complete=False#任务是否完成

        self.initial_x = None
        self.current_x = None

        self.flag=UInt32()#发送消息flag
        self.flag.data=0

    def set_speed(self,linearx,angularz):
        twist=Twist()
        twist.linear.x=linearx
        twist.linear.y=0.0
        twist.linear.z=0.0
        twist.angular.x=0.0
        twist.angular.y=0.0
        twist.angular.z=angularz
        self.pub_vel.publish(twist)
    
    def flag_callback(self,msg):
        if msg.data==0:
            self.start_moving=True
            self.get_logger().info("OK")

    #def color_callback(self,msg):
    #    if msg.data is not None:
    #        self.start_moving=True

    def odom_callback(self, msg):
        if self.initial_x is None:
            self.initial_x = msg.pose.pose.position.x
        self.current_x = msg.pose.pose.position.x

    def move(self):
        if self.start_moving:#判断start_moving，为True时启动
            distance = abs(self.current_x - self.initial_x)
            if distance < 1.1:
                self.set_speed(0.1,0.0)
            else:
                self.set_speed(0.0,0.0)
                self.task_complete=True
                time.sleep(3)
                self.flag.data=1#完成后发布话题flag=1,开始导航
                self.pub_flag.publish(self.flag)

 
def main(args=None):
    rclpy.init(args=args)
    node=MoveForward("start")
    while rclpy.ok() and not node.task_complete:
        rclpy.spin_once(node)
        node.move()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

