import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Pose2D, Pose, Twist

class CommandListener(Node):
    def __init__(self):
        super().__init__('command_listener')

        self.pub_vel = self.create_publisher(Twist, "/controller/cmd_vel", 1)
        self.subscription = self.create_subscription(
            String,
            'command',
            self.command_callback,
            10)
        
        self.get_logger().info('Command Listener Node Started')

    def command_callback(self, msg):
        command = msg.data
        
        if command == '1':
            twist = Twist()
            twist.linear.x = 0.3
            self.pub_vel.publish(twist)
            self.get_logger().info('Moving Forward')
        elif command == '2':
            twist = Twist()
            twist.angular.z = 0.3
            self.pub_vel.publish(twist)
            self.get_logger().info('Turning Left')
        elif command == '3':
            twist = Twist()
            twist.angular.z = -0.3
            self.pub_vel.publish(twist)
            self.get_logger().info('Turning Right')
        elif command == '4':
            twist = Twist()
            self.pub_vel.publish(twist)
            self.get_logger().info('Stopping')
        else:
            self.get_logger().warn(f'Unknown command received: {command}')


def main(args=None):
    rclpy.init(args=args)
    node = CommandListener()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
