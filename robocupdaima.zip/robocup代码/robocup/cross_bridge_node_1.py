#!/usr/bin/env python3
# encoding: utf-8
# @data:2023/12/18
# @author:aiden
# 上坡
import os
import cv2
import time
import math
import rclpy
import queue
import signal
import threading
import numpy as np
from sdk import pid, common, fps
from rclpy.node import Node
from std_srvs.srv import SetBool
from std_srvs.srv import Trigger
from sensor_msgs.msg import Image,Imu
from geometry_msgs.msg import Twist,Pose2D, Pose, PoseWithCovarianceStamped, TransformStamped,Quaternion
from servo_controller_msgs.msg import ServosPosition
from servo_controller.bus_servo_control import set_servo_position
from std_msgs.msg import UInt32


class UpplatformNode(Node):
    def __init__(self, name):
        rclpy.init()
        super().__init__(name, allow_undeclared_parameters=True, automatically_declare_parameters_from_overrides=True)
        self.name = name
        signal.signal(signal.SIGINT, self.shutdown)
        self.running = True
        self.turn = False
        self.plane_high = self.get_parameter('plane_distance').value
        self.debug = self.get_parameter('debug').value
        self.twist = Twist()
        self.image_queue = queue.Queue(maxsize=2)
        self.subscription = self.create_subscription(Imu, '/imu', self.imu_callback, 10)
#        self.left_roi = [290, 300, 165, 175]
#        self.center_roi = [290, 300, 315, 325]
#        self.right_roi = [290, 300, 465, 475]
        self.left_roi = [0, 50, 50, 100]      # 左上角 ROI
        self.center_roi = [295, 50,345 , 100]   # 正上方 ROI
        self.right_roi = [590, 50, 640, 100]   # 右上角 ROI

        self.pid_x = pid.PID(1.0, 0.0, 0.0)

        self.debug = self.get_parameter('debug').value
        self.joints_pub = self.create_publisher(ServosPosition, '/servo_controller', 1) # 舵机控制
        self.mecanum_pub = self.create_publisher(Twist, '/controller/cmd_vel', 1)  # 底盘控制

        self.flag = UInt32()
        self.pub_flag=self.create_publisher(UInt32,"flag",1)#发布是否开始夹取
        
        self.bridge_subscriber = self.create_subscription(
            UInt32,
            "flag",  # 订阅的主题
            self.start_flag_callback,
            10
        )

        self.current_roll=None
        self.i=0 #用来标志结束

        self.create_subscription(Image, '/depth_cam/depth/image_raw', self.depth_callback, 1)
        self.client = self.create_client(SetBool, '/depth_cam/set_ldp_enable')
        self.client.wait_for_service()
        msg = SetBool.Request()
        msg.data = False
        future = self.client.call_async(msg)
        rclpy.spin_until_future_complete(self, future)
        self.client = self.create_client(Trigger, '/controller_manager/init_finish')
        self.client.wait_for_service()

        self.mecanum_pub.publish(Twist())
        set_servo_position(self.joints_pub, 1, ((1, 500), (2, 700), (3, 85), (4, 150), (5, 500), (10, 200)))
        time.sleep(1)

        #threading.Thread(target=self.main, daemon=True).start()
        self.create_service(Trigger, '~/init_finish', self.get_node_state)
        self.get_logger().info('\033[1;32m%s\033[0m' % 'start')

    def get_node_state(self, request, response):
        response.success = True
        return response

    def set_speed(self,linearx,angularz):
        twist=Twist()
        twist.linear.x=linearx
        twist.linear.y=0.0
        twist.linear.z=0.0
        twist.angular.x=0.0
        twist.angular.y=0.0
        twist.angular.z=angularz
        self.mecanum_pub.publish(twist)

    def qua2rpy(self,qua):
        if type(qua) == Quaternion:
            x, y, z, w = qua.x, qua.y, qua.z, qua.w
        else:
            x, y, z, w = qua[0], qua[1], qua[2], qua[3]
        roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
        pitch = math.asin(2 * (w * y - x * z))
        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (z * z + y * y))
  
        return roll, pitch, yaw
    
    def imu_callback(self, msg):
        qua = msg.orientation
        roll,pitch,yaw = self.qua2rpy(qua)
        self.current_roll=roll

    def depth_callback(self, ros_depth_image):
        depth_image = np.ndarray(shape=(ros_depth_image.height, ros_depth_image.width), dtype=np.uint16,
                                 buffer=ros_depth_image.data)
        if self.image_queue.full():
            # 如果队列已满，丢弃最旧的图像
            self.image_queue.get()
        # 将图像放入队列
        self.image_queue.put(depth_image)

    def shutdown(self, signum, frame):
        self.running = False
        self.get_logger().info('\033[1;32m%s\033[0m' % "shutdown")

    def get_roi_distance(self, depth_image, roi):
        roi_image = depth_image[roi[0]:roi[1], roi[2]:roi[3]]
        try:
            distance = round(float(np.mean(roi_image[np.logical_and(roi_image > 0, roi_image < 30000)]) / 1000), 3)
        except:
            distance = 0
        return distance

    def move_policy(self, left_distance, center_distance, right_distance):
        if left_distance - right_distance > 0.02:         #改运动策略
            self.twist.angular.z = 0.0
        elif right_distance - left_distance > 0.02:
            self.twist.angular.z = 0.0
        else:
            self.twist.angular.z = 0.0
        if abs(center_distance - self.plane_high) > 0.03:        #可以修改
            self.twist = Twist()
            #self.running = False 停车
        else:
            self.twist.linear.x = 0.1

        self.mecanum_pub.publish(self.twist)

    def turn(self):
        pass


    def start_flag_callback(self,msg):
        self.get_logger().info(f"Received msg: {msg.data}")
        if msg.data == 2:
            self.running = True
            threading.Thread(target=self.main, daemon=True).start()
    
    
    def main(self):
        count = 0
        cur_time = time.time()
        while self.running:
            try:
                depth_image = self.image_queue.get(block=True, timeout=1)
            except queue.Empty:
                if not self.running:
                    break
                else:
                    continue
            depth_color_map = cv2.applyColorMap(cv2.convertScaleAbs(depth_image, alpha=0.45), cv2.COLORMAP_JET)
            if self.debug:
                #cv2.circle(depth_color_map, (int((self.left_roi[2] + self.left_roi[3]) / 2), int((self.left_roi[0] + self.left_roi[1]) / 2)), 10, (0, 0, 0), -1)
                #cv2.circle(depth_color_map, (int((self.center_roi[2] + self.center_roi[3]) / 2), int((self.center_roi[0] + self.center_roi[1]) / 2)), 10, (0, 0, 0), 
                #cv2.circle(depth_color_map, (int((self.right_roi[2] + self.right_roi[3]) / 2), int((self.right_roi[0] + self.right_roi[1]) / 2)), 10, (0, 0, 0), -1)
                #left_distance = self.get_roi_distance(depth_image, self.left_roi)
                #center_distance = self.get_roi_distance(depth_image, self.center_roi)
                #right_distance = self.get_roi_distance(depth_image, self.right_roi)
                #count += 1
                #self.get_logger().info(str([left_distance, center_distance, right_distance]))
                #if count > 50 and not math.isnan(center_distance):
                #    count = 0
                   # self.plane_high = center_distance                   #设成0
                #    self.plane_high = 0
                 #   data = {'/**': {'ros__parameters': {'plane_distance': {}}}}
                 #   data['/**']['ros__parameters']['plane_distance'] = self.plane_high
                 #   common.save_yaml_data(data, os.path.join(
                 #       os.path.abspath(os.path.join(os.path.split(os.path.realpath(__file__))[0], '../..')),
               #         'config/bridge_plane_distance.yaml'))
                    self.debug = False
            else:
                left_roi = [self.left_roi[0], self.left_roi[1], self.left_roi[2] - 80, self.left_roi[3] - 80] 
                right_roi = [self.right_roi[0], self.right_roi[1], self.right_roi[2] + 80, self.right_roi[3] + 80] 
                cv2.circle(depth_color_map, (int((left_roi[2] + left_roi[3]) / 2), int((left_roi[0] + left_roi[1]) / 2)), 10, (0, 0, 0), -1)
                cv2.circle(depth_color_map, (int((self.center_roi[2] + self.center_roi[3]) / 2), int((self.center_roi[0] + self.center_roi[1]) / 2)), 10, (0, 0, 0), -1)
                cv2.circle(depth_color_map, (int((right_roi[2] + right_roi[3]) / 2), int((right_roi[0] + right_roi[1]) / 2)), 10, (0, 0, 0), -1)
                left_distance = self.get_roi_distance(depth_image, left_roi)
                center_distance = self.get_roi_distance(depth_image, self.center_roi)
                right_distance = self.get_roi_distance(depth_image, right_roi)
                height, width = depth_image.shape
                row = width // 2    # 使用图像中间行进行检测
                depth_values = depth_image[row]  # 获取该行的深度值
                #depth_values = depth_values.astype(int)
                # 找到深度一致的区域
                same_depth_indices = []
                depth_threshold = 0.05 # 定义深度阈值
                tolerance=0  #tol
                for i in range(width//2 , 0 , -1):
                    if abs(depth_values[i + 1] - depth_values[i]) < depth_threshold:
                        same_depth_indices.append(i)
                for i in range(width//2 - 1, width):
                    if abs(depth_values[i] - depth_values[i - 1]) < depth_threshold:
                        same_depth_indices.append(i)
                #for i in range(width//2 , 0 , -1):
                #    if abs(depth_values[i + 1] - depth_values[i]) < depth_threshold:
                #        same_depth_indices.append(i)

                self.get_logger().info(str(depth_values[same_depth_indices[2]]))
                #如果深度值大于就会停止

                if abs(self.current_roll+2.88) <0.1:
                    self.i=1
                if self.i==1 and abs(abs(self.current_roll)-math.pi)<0.05:
                    self.i=2
                if self.i==2:
                    #time.sleep(0.5)           
                    self.set_speed(0.0,0.0)
                    self.flag.data=3
                    self.pub_flag.publish(self.flag)
                    time.sleep(1)
                    self.destroy_node()
                    rclpy.shutdown()
                    
                #if time.time() - cur_time > 12  :
                #    self.flag.data=13  #完成后发布话题flag=3,开始抓取
                #    self.pub_flag.publish(self.flag)
                #    self.mecanum_pub.publish(Twist())
                #    time.sleep(1)                
                #    self.destroy_node()
                #    rclpy.shutdown()
            
                image_center= width // 2
                # 计算相同深度区域的中心点
                if same_depth_indices:
                    center_index = sum(same_depth_indices) // len(same_depth_indices)
                    self.get_logger().info(str([center_index, image_center]))

                    # 根据当前中心点与图像中心的差异调整运动
                    self.pid_x.SetPoint=center_index
                    self.pid_x.update(image_center)
                    self.twist.angular.z=common.set_range(-self.pid_x.output, -0.5, 0.5)

                    self.twist.linear.x = 0.3  # 向前移动
                    self.mecanum_pub.publish(self.twist)  # 发布运动指令

                else:
                    if math.isnan(left_distance):
                        left_distance = 0
                    if math.isnan(center_distance):
                        center_distance = 0
                    if math.isnan(right_distance):
                        right_distance = 0
                    self.move_policy(left_distance, center_distance, right_distance)

            #cv2.imshow('depth_color_map', depth_color_map)
            k = cv2.waitKey(1) & 0xFF
            if k == 27 or k == ord('q'):
                self.running = False
        self.mecanum_pub.publish(Twist())
        #self.get_logger().info('\033[1;32m%s\033[0m' % 'shutdown')
        

def main():
    node = UpplatformNode('cross_bridge_node_1')
    rclpy.spin(node)
    #node.destroy_node()

if __name__ == "__main__":
    main()




