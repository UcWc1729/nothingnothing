import os
import math
import time
import rclpy
import signal
import threading
from rclpy.node import Node
import sdk.common as common
from std_srvs.srv import Trigger
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from std_msgs.msg import UInt32 #导入消息类型
from geometry_msgs.msg import Pose2D, Pose, Twist, PoseWithCovarianceStamped, TransformStamped,Pose, Quaternion


class Rotate(Node):
    def __init__(self, name):
        super().__init__(name)
        self.subscription = self.create_subscription(Imu, '/imu', self.imu_callback, 10)
        self.sub_flag=self.create_subscription(UInt32,"flag",self.flag_callback,10)

        self.pub_vel = self.create_publisher(Twist, "/controller/cmd_vel", 1)
        self.pub_flag=self.create_publisher(UInt32,"flag",1)#发布是否开始前行

        self.target_yaw =0.0
        self.current_yaw=None

        self.start=False

        self.flag=UInt32()#发送消息flag
        self.flag.data=0

        self.tolerance = 0.05

        # 标记任务是否完成
        self.task_complete = False

        self.thread=threading.Thread(target=self.rotate,daemon=True)

    def qua2rpy(self,qua):
        if type(qua) == Quaternion:
            x, y, z, w = qua.x, qua.y, qua.z, qua.w
        else:
            x, y, z, w = qua[0], qua[1], qua[2], qua[3]
        roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
        pitch = math.asin(2 * (w * y - x * z))
        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (z * z + y * y))
  
        return roll, pitch, yaw
    
    def flag_callback(self,flag):
        if flag.data==14:
            self.start=True
            self.target_yaw=math.pi/2+0.5
            self.thread.start()
            self.get_logger().info("程序启动")
           
    def imu_callback(self, msg):
        qua = msg.orientation
        roll,pitch,yaw = self.qua2rpy(qua)
        self.current_yaw=yaw

    def rotate(self):
        if self.current_yaw!=None and self.start:
            error_yaw = self.target_yaw - self.current_yaw

            if abs(error_yaw) > self.tolerance:
                if error_yaw>0:
                    twist = Twist()
                    twist.angular.z = 0.3
                    self.pub_vel.publish(twist)
                if error_yaw<0:
                    twist = Twist()
                    twist.angular.z = -0.3
                    self.pub_vel.publish(twist)
            else:
                self.pub_vel.publish(Twist())
                time.sleep(2)
                self.flag.data=8#完成后发布话题flag=8
                self.pub_flag.publish(self.flag)
                self.get_logger().info("完成旋转")
                 
                self.start = False
                self.task_complete=True
                
def main(args=None):
    rclpy.init(args=args)
    node = Rotate("turn_1")
    while rclpy.ok() and node.task_complete!=True:
        rclpy.spin_once(node)
        node.rotate()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
