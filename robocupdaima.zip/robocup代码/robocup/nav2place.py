import math
import rclpy
import time
import numpy as np
from rclpy.node import Node
import sdk.common as common
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import UInt32
import threading
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult

class Navigation(Node):
    def __init__(self,name):
        super().__init__(name)
        self.pub_flag=self.create_publisher(UInt32,"flag",10)

        self.sub_flag=self.create_subscription(UInt32,"flag",self.flag_callback,10)

        self.navigator = BasicNavigator()

        self.navigator.waitUntilNav2Active()#等待Nav2启动
       
        self.timer = self.create_timer(1.0, self.timer_callback)
        
        self.timer_active=True#状态，为1时启动回调函数，为0时关闭

        self.start=False#是否开始导航
        self.flag=UInt32()#对外发布完成情况，是否开始去取货点

        self.i=0

    def flag_callback(self,msg):
        if msg.data==6:#接受start发出的flag话题，flag=1时启动
            self.start=True

    def timer_callback(self):
        if not self.timer_active:
            return #如果已经到达目标，直接返回
        if self.start!=True:
            return

        # Create the PoseStamped message
        goal_pose = PoseStamped()
        goal_pose.header.frame_id = 'map'
        goal_pose.header.stamp = self.navigator.get_clock().now().to_msg()
        #确定位置
        goal_pose.pose.position.x = 3.6
        goal_pose.pose.position.y = 1.7
        goal_pose.pose.position.z = 0.0
        #确定方向
        goal_pose.pose.orientation.x = 0.0
        goal_pose.pose.orientation.y = 0.0
        goal_pose.pose.orientation.z = 0.7071
        goal_pose.pose.orientation.w = 0.7071
        #绕z轴顺时针90度，w=0.7071，x=y=0,z=0.7071;逆时针的话将z改为-0.7071

        # Publish the goal
        self.navigator.goToPose(goal_pose)
        self.get_logger().info('Published goal pose: {}'.format(goal_pose))

        while not self.navigator.isTaskComplete():
            self.i=self.i+1
            feedback=self.navigator.getFeedback()
            if feedback and self.i % 5 == 0:
                self.get_logger().info("还未到达")
                
        result=self.navigator.getResult()
        if result == TaskResult.SUCCEEDED:
             self.get_logger().info("成功导航")
             self.timer_active=False
             self.timer.cancel()
        elif result == TaskResult.CANCELED:
             self.get_logger().info("取消导航")
             self.timer_active=False
             self.timer.cancel()
        elif result == TaskResult.FAILED:
             self.get_logger().info("导航失败")
             self.timer_active=False
             self.timer.cancel()

        self.flag.data=8
        self.pub_flag.publish(self.flag)#完成任务后发布flag节点消息，flag=2
        time.sleep(1)
        self.destroy_node()#销毁节点
        rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    node = Navigation("nav2place")
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

