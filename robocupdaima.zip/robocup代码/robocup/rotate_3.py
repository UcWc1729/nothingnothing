import os
import math
import time
import rclpy
import signal
import threading
from rclpy.node import Node
import sdk.common as common
from std_srvs.srv import Trigger
from nav_msgs.msg import Odometry
from std_msgs.msg import UInt32 #导入消息类型
from geometry_msgs.msg import Pose2D, Pose, Twist, PoseWithCovarianceStamped, TransformStamped,Pose, Quaternion


class Rotate(Node):
    def __init__(self, name):
        super().__init__(name)
        self.subscription = self.create_subscription(Odometry, '/odom_raw', self.odom_callback, 10)
        self.sub_flag=self.create_subscription(UInt32,"flag",self.flag_callback,10)

        self.pub_vel = self.create_publisher(Twist, "/controller/cmd_vel", 1)
        self.pub_flag=self.create_publisher(UInt32,"flag",1)#发布是否开始前行

        self.initial_yaw = None
        self.target_yaw = None
        self.current_yaw=None

        self.start=False

        self.flag=UInt32()#发送消息flag
        self.flag.data=0

        self.tolerance = 0.01

        # 标记任务是否完成
        self.task_complete = False

        self.thread=threading.Thread(target=self.rotate)

    def qua2rpy(self,qua):
        if type(qua) == Quaternion:
            x, y, z, w = qua.x, qua.y, qua.z, qua.w
        else:
            x, y, z, w = qua[0], qua[1], qua[2], qua[3]
        roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
        pitch = math.asin(2 * (w * y - x * z))
        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (z * z + y * y))
  
        return roll, pitch, yaw
    
    def flag_callback(self,flag):
        if flag.data==33:
            self.start=True
            self.thread.start()
            self.get_logger().info("程序启动")
    
    def odom_callback(self, msg):
        qua = msg.pose.pose.orientation
        roll,pitch,yaw = self.qua2rpy(qua)
        self.current_yaw=yaw
        if self.start:
            if self.initial_yaw is None:
                self.initial_yaw = self.current_yaw
                self.target_yaw = self.initial_yaw + math.pi/1.1
                if self.target_yaw > math.pi:
                    self.target_yaw -= 2 * math.pi

    def rotate(self):
        if self.task_complete==False and self.initial_yaw!=None:
            error_yaw = self.target_yaw - self.current_yaw

            #if abs(error_yaw) > self.tolerance:
            twist = Twist()
            twist.angular.z = 0.3
            self.pub_vel.publish(twist)
            time.sleep(11)
            #else:
            self.pub_vel.publish(Twist())
            self.get_logger().info("完成旋转")
            self.task_complete = True
            time.sleep(3)
            self.flag.data=34#完成后发布话题flag=6,开始导航去卸货点
            self.pub_flag.publish(self.flag)
                
def main(args=None):
    rclpy.init(args=args)
    node = Rotate("rotate_3")
    while rclpy.ok() and not node.task_complete:
        rclpy.spin_once(node)
        node.rotate()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
