import os
import math
import time
import rclpy
import signal
import threading
from rclpy.node import Node
from std_srvs.srv import Trigger
from nav_msgs.msg import Odometry
from std_msgs.msg import String,UInt32
from geometry_msgs.msg import Pose2D, Pose, Twist, PoseWithCovarianceStamped, TransformStamped,Quaternion
from sensor_msgs.msg import Imu

class MoveForward(Node):
    def __init__(self,name):
        super().__init__(name)
        self.pub_vel=self.create_publisher(Twist,"/controller/cmd_vel",1)#发布速度控制
        self.pub_flag=self.create_publisher(UInt32,"flag",1)#发布是否开始导航

        self.sub_flag=self.create_subscription(UInt32,"flag",self.flag_callback,10)#接受flag数据
        self.subscription = self.create_subscription(Imu, '/imu', self.imu_callback, 10)

        self.start_moving=False#是否启动
        self.task_complete=False#任务是否完成

        self.initial_x = None
        self.current_x = None

        self.initial_roll = None
        self.target_roll = 0.0
        self.current_roll=None

        self.flag=UInt32()#发送消息flag
        self.flag.data=0

        self.i=0

    def set_speed(self,linearx,angularz):
        twist=Twist()
        twist.linear.x=linearx
        twist.linear.y=0.0
        twist.linear.z=0.0
        twist.angular.x=0.0
        twist.angular.y=0.0
        twist.angular.z=angularz
        self.pub_vel.publish(twist)

    def qua2rpy(self,qua):
        if type(qua) == Quaternion:
            x, y, z, w = qua.x, qua.y, qua.z, qua.w
        else:
            x, y, z, w = qua[0], qua[1], qua[2], qua[3]
        roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
        pitch = math.asin(2 * (w * y - x * z))
        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (z * z + y * y))
  
        return roll, pitch, yaw
    
    def imu_callback(self, msg):
        qua = msg.orientation
        roll,pitch,yaw = self.qua2rpy(qua)
        self.current_roll=roll
        if self.start_moving:
            if self.initial_roll is None:
                self.initial_roll = self.current_roll

    def flag_callback(self,msg):
        if msg.data==15:#接受start发出的flag话题，flag=15时启动
            self.get_logger().info("收到启动信号")
            self.start_moving=True

    def move(self):
        if self.start_moving:#判断start_moving，为True时启动
            #self.get_logger().info(str(self.current_roll))
            if abs(self.current_roll+2.81) <0.07:
                self.i=1
            if self.i==1 and abs(abs(self.current_roll)-math.pi)<0.05:
                self.i=2
            if self.i==0:
                self.set_speed(0.1,0.0)
            if self.i==1:
                self.set_speed(0.3,0.0)
            if self.i==2:
                time.sleep(0.3)           
                self.set_speed(0.0,0.0)
                self.task_complete=True
                self.flag.data=8#完成后发布话题flag=9,开始夹取物体
                self.pub_flag.publish(self.flag)

 
def main(args=None):
    rclpy.init(args=args)
    node=MoveForward("up_1")
    while rclpy.ok() and not node.task_complete:
        rclpy.spin_once(node)
        node.move()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()



