import os
import math
import time
import rclpy
import signal
import threading
from rclpy.node import Node
from std_srvs.srv import Trigger
from nav_msgs.msg import Odometry
from std_msgs.msg import String,UInt32
from geometry_msgs.msg import Pose2D, Pose, Twist, PoseWithCovarianceStamped, TransformStamped

class MoveForward(Node):
    def __init__(self,name):
        super().__init__(name)
        self.pub_vel=self.create_publisher(Twist,"/controller/cmd_vel",1)#发布速度控制
        self.pub_flag=self.create_publisher(UInt32,"flag",1)#发布是否开始导航

        self.odom_sub = self.create_subscription(Odometry, 'odom_raw', self.odom_callback, 10)#接收odom数据
        self.sub_flag=self.create_subscription(UInt32,"flag",self.flag_callback,10)#接受flag数据

        self.start_moving=False#是否启动
        self.task_complete=False#任务是否完成

        self.initial_x = None
        self.current_x = None

        self.flag=UInt32()#发送消息flag
        self.flag.data=0

    def set_speed(self,linearx,angularz):
        twist=Twist()
        twist.linear.x=linearx
        twist.linear.y=0.0
        twist.linear.z=0.0
        twist.angular.x=0.0
        twist.angular.y=0.0
        twist.angular.z=angularz
        self.pub_vel.publish(twist)

    def flag_callback(self,msg):
        if msg.data==7:#接受start发出的flag话题，flag=7时启动
            self.get_logger().info("收到启动信号")
            self.start_moving=True

    #def color_callback(self,msg):
    #    if msg.data is not None:
    #        self.start_moving=True

    def odom_callback(self, msg):
        if self.start_moving:
            if self.initial_x is None:
                self.initial_x = msg.pose.pose.position.x
            self.current_x = msg.pose.pose.position.x

    def move(self):
        if self.start_moving and self.initial_x!=None:#判断start_moving，为True时启动
            distance = self.current_x - self.initial_x
            self.get_logger().info(f"距离：{distance}")
            if abs(distance) < 1.0:
                self.set_speed(0.1,0.0)
            else:
                self.set_speed(0.0,0.0)
                self.task_complete=True
                self.flag.data=9#完成后发布话题flag=9
                self.pub_flag.publish(self.flag)

 
def main(args=None):
    rclpy.init(args=args)
    node=MoveForward("up_platform_place")
    while rclpy.ok() and not node.task_complete:
        rclpy.spin_once(node)
        node.move()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()



