import os
import math
import time
import rclpy
import signal
import threading
from rclpy.node import Node
import sdk.common as common
from std_srvs.srv import Trigger
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Pose2D, Pose, Twist, PoseWithCovarianceStamped, TransformStamped,Pose, Quaternion


class Rotate(Node):
    def __init__(self, name):
        super().__init__(name)
        self.subscription = self.create_subscription(Odometry, '/odom_raw', self.odom_callback, 10)
        self.pub_vel = self.create_publisher(Twist, "/controller/cmd_vel", 1)

        self.initial_yaw = None
        self.target_yaw = None
        self.current_yaw=None

        self.tolerance = 0.01

        # 标记任务是否完成
        self.task_complete = False

    def qua2rpy(self,qua):
        if type(qua) == Quaternion:
            x, y, z, w = qua.x, qua.y, qua.z, qua.w
        else:
            x, y, z, w = qua[0], qua[1], qua[2], qua[3]
        roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
        pitch = math.asin(2 * (w * y - x * z))
        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (z * z + y * y))
  
        return roll, pitch, yaw
    
    def odom_callback(self, msg):
        qua = msg.pose.pose.orientation
        roll,pitch,yaw = self.qua2rpy(qua)
        self.current_yaw=yaw
        if self.initial_yaw is None:
            self.initial_yaw = self.current_yaw
            self.target_yaw = self.initial_yaw + math.pi / 1.6
            if self.target_yaw > math.pi:
                self.target_yaw -= 2 * math.pi

    def rotate(self):
        if self.initial_yaw is not None:
            error_yaw = self.target_yaw - self.current_yaw
            if error_yaw > math.pi:
                error_yaw -= 2 * math.pi
            elif error_yaw < -math.pi:
                error_yaw += 2 * math.pi

            if abs(error_yaw) > self.tolerance:
                twist = Twist()
                twist.angular.z = 0.3
                self.pub_vel.publish(twist)
            else:
                self.task_complete = True
                twist = Twist()
                twist.angular.z = 0.0
                self.pub_vel.publish(twist)
                
def main(args=None):
    rclpy.init(args=args)
    node = Rotate("rotate")
    while rclpy.ok() and not node.task_complete:
        rclpy.spin_once(node)
        node.rotate()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
