from setuptools import find_packages, setup
from glob import glob
import os

package_name = 'robocup'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share',package_name,'launch'),glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='hiwonder@hiwonder.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            "rotate=robocup.rotate:main",
            "track_and_grab=robocup.track_and_grab:main",
            "track_and_grab_1=robocup.track_and_grab_1:main",
            "track_and_grab_2=robocup.track_and_grab_2:main",
            "start=robocup.start:main",
            "nav2pick=robocup.nav2pick:main",
            "cross_bridge_node_1=robocup.cross_bridge_node_1:main",
            "cross_bridge_node_2=robocup.cross_bridge_node_2:main",
            "cross_bridge_node_3=robocup.cross_bridge_node_3:main",
            "turn_0=robocup.turn_0:main",
            "up_platform_pick=robocup.up_platform_pick:main",
            "rotate_1=robocup.rotate_1:main",
            "down_platform_pick=robocup.down_platform_pick:main",
            "nav2place=robocup.nav2place:main",
            "up_platform_place=robocup.up_platform_place:main",
            "down_platform_place=robocup.down_platform_place:main",
            "rotate_2=robocup.rotate_2:main",
            "nav2finish=robocup.nav2finish:main",
            "up_platform_finish=robocup.up_platform_finish:main",
            "turn_1=robocup.turn_1:main",
            "up_1=robocup.up_1:main",
            "up_2=robocup.up_2:main",
            "up_3=robocup.up_3:main",
            "down=robocup.down:main",
            "touch1=robocup.touch1:main",
            "cross_bridge_node_4=robocup.cross_bridge_node_4:main",
            "down_platform_pick_1=robocup.down_platform_pick_1:main",
            "cross_bridge_node_5=robocup.cross_bridge_node_5:main",
            "rotate_3=robocup.rotate_3:main"
        ],
    },
)
